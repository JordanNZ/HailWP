<?php

class __Mustache_a119da6d037bc40aec10f8ac5142ceab extends Mustache_Template
{
    private $lambdaHelper;

    public function renderInternal(Mustache_Context $context, $indent = '')
    {
        $this->lambdaHelper = new Mustache_LambdaHelper($this->mustache, $context);
        $buffer = '';
        $blocksContext = array();

        $buffer .= $indent . '<div class="wrap">
';
        $buffer .= $indent . '
';
        $buffer .= $indent . '  <h2>';
        $value = $this->resolveValue($context->find('title'), $context);
        $buffer .= htmlspecialchars($value, 2, 'UTF-8');
        $buffer .= '</h2>
';
        $buffer .= $indent . '
';
        $buffer .= $indent . '  <div class="';
        $value = $this->resolveValue($context->find('test_class'), $context);
        $buffer .= htmlspecialchars($value, 2, 'UTF-8');
        $buffer .= '"><p>';
        $value = $this->resolveValue($context->find('test_text'), $context);
        $buffer .= htmlspecialchars($value, 2, 'UTF-8');
        $buffer .= '</p></div>
';
        $buffer .= $indent . '
';
        // 'import_results' section
        $value = $context->find('import_results');
        $buffer .= $this->section5c17e4078d655e9add08f81421dfe131($context, $indent, $value);
        $buffer .= $indent . '
';
        // 'deletion_results' section
        $value = $context->find('deletion_results');
        $buffer .= $this->section56c87778ddf2a0be6719f120ccbfe059($context, $indent, $value);
        $buffer .= $indent . '
';
        // 'settings_reset' section
        $value = $context->find('settings_reset');
        $buffer .= $this->section0e62cf974a12df58abcba8baca48fe34($context, $indent, $value);
        $buffer .= $indent . '
';
        $buffer .= $indent . '  ';
        $value = $this->resolveValue($context->find('help'), $context);
        $buffer .= $value;
        $buffer .= '
';
        $buffer .= $indent . '
';
        $buffer .= $indent . '  <form method="post" name="setup-options" action="options.php">
';
        $buffer .= $indent . '
';
        $buffer .= $indent . '    <input type="hidden" name="option_page" value="';
        $value = $this->resolveValue($context->find('plugin_name'), $context);
        $buffer .= htmlspecialchars($value, 2, 'UTF-8');
        $buffer .= '" />
';
        $buffer .= $indent . '    <input type="hidden" name="action" value="update" />
';
        $buffer .= $indent . '    ';
        $value = $this->resolveValue($context->find('settings_nonce'), $context);
        $buffer .= $value;
        $buffer .= '
';
        $buffer .= $indent . '    <input type="hidden" name="_wp_http_referer" value="';
        $value = $this->resolveValue($context->find('return_uri'), $context);
        $buffer .= htmlspecialchars($value, 2, 'UTF-8');
        $buffer .= '">
';
        $buffer .= $indent . '
';
        $buffer .= $indent . '    <fieldset>
';
        $buffer .= $indent . '      <legend class="screen-reader-text"><span>Client ID</span></legend>
';
        $buffer .= $indent . '      <label for="';
        $value = $this->resolveValue($context->find('plugin_name'), $context);
        $buffer .= htmlspecialchars($value, 2, 'UTF-8');
        $buffer .= '-client_id">
';
        $buffer .= $indent . '        <input type="text" class="';
        $value = $this->resolveValue($context->find('plugin_name'), $context);
        $buffer .= htmlspecialchars($value, 2, 'UTF-8');
        $buffer .= '-client_id" id="';
        $value = $this->resolveValue($context->find('plugin-name'), $context);
        $buffer .= htmlspecialchars($value, 2, 'UTF-8');
        $buffer .= '-client_id" name="';
        $value = $this->resolveValue($context->find('plugin_name'), $context);
        $buffer .= htmlspecialchars($value, 2, 'UTF-8');
        $buffer .= '[client_id]"  value="';
        $value = $this->resolveValue($context->find('client_id'), $context);
        $buffer .= htmlspecialchars($value, 2, 'UTF-8');
        $buffer .= '"  />
';
        $buffer .= $indent . '        <span>Client ID</span>
';
        $buffer .= $indent . '      </label>
';
        $buffer .= $indent . '    </fieldset>
';
        $buffer .= $indent . '
';
        $buffer .= $indent . '    <fieldset>
';
        $buffer .= $indent . '      <legend class="screen-reader-text"><span>Client Secret</span></legend>
';
        $buffer .= $indent . '      <label for="';
        $value = $this->resolveValue($context->find('plugin_name'), $context);
        $buffer .= htmlspecialchars($value, 2, 'UTF-8');
        $buffer .= '-client_secret">
';
        $buffer .= $indent . '        <input type="text" class="';
        $value = $this->resolveValue($context->find('plugin_name'), $context);
        $buffer .= htmlspecialchars($value, 2, 'UTF-8');
        $buffer .= '-client_secret" id="';
        $value = $this->resolveValue($context->find('plugin_name'), $context);
        $buffer .= htmlspecialchars($value, 2, 'UTF-8');
        $buffer .= '-client_secret" name="';
        $value = $this->resolveValue($context->find('plugin_name'), $context);
        $buffer .= htmlspecialchars($value, 2, 'UTF-8');
        $buffer .= '[client_secret]"  value="';
        $value = $this->resolveValue($context->find('client_secret'), $context);
        $buffer .= htmlspecialchars($value, 2, 'UTF-8');
        $buffer .= '"  />
';
        $buffer .= $indent . '        <span>Client secret</span>
';
        $buffer .= $indent . '      </label>
';
        $buffer .= $indent . '    </fieldset>
';
        $buffer .= $indent . '
';
        $buffer .= $indent . '    <!-- Tags and stuff -->
';
        $buffer .= $indent . '    <fieldset style="';
        // 'show_ptag' inverted section
        $value = $context->find('show_ptag');
        if (empty($value)) {
            
            $buffer .= 'display: none;';
        }
        $buffer .= '">
';
        $buffer .= $indent . '      <legend class="screen-reader-text"><span>Primary Private Tag ID</span></legend>
';
        $buffer .= $indent . '      <label for="';
        $value = $this->resolveValue($context->find('plugin_name'), $context);
        $buffer .= htmlspecialchars($value, 2, 'UTF-8');
        $buffer .= '-primary_ptag">
';
        $buffer .= $indent . '        <input type="text" class="';
        $value = $this->resolveValue($context->find('plugin_name'), $context);
        $buffer .= htmlspecialchars($value, 2, 'UTF-8');
        $buffer .= '-primary_ptag" id="';
        $value = $this->resolveValue($context->find('plugin_name'), $context);
        $buffer .= htmlspecialchars($value, 2, 'UTF-8');
        $buffer .= '-primary_ptag" name="';
        $value = $this->resolveValue($context->find('plugin_name'), $context);
        $buffer .= htmlspecialchars($value, 2, 'UTF-8');
        $buffer .= '[primary_ptag]" value="';
        $value = $this->resolveValue($context->find('primary_ptag'), $context);
        $buffer .= htmlspecialchars($value, 2, 'UTF-8');
        $buffer .= '" />
';
        $buffer .= $indent . '        <span>Primary private tag ID</span>
';
        $buffer .= $indent . '      </label>
';
        $buffer .= $indent . '    </fieldset>
';
        $buffer .= $indent . '
';
        $buffer .= $indent . '    <!-- REDIS -->
';
        $buffer .= $indent . '    <!-- if has predis -->
';
        $buffer .= $indent . '    <!-- <fieldset>
';
        $buffer .= $indent . '      <legend class="screen-reader-text"><span>Enable Redis caching</span></legend>
';
        $buffer .= $indent . '      <label for="';
        $value = $this->resolveValue($context->find('plugin_name'), $context);
        $buffer .= htmlspecialchars($value, 2, 'UTF-8');
        $buffer .= '-enable_redis">
';
        $buffer .= $indent . '        <input type="checkbox" id="';
        $value = $this->resolveValue($context->find('plugin_name'), $context);
        $buffer .= htmlspecialchars($value, 2, 'UTF-8');
        $buffer .= '-redis_enabled" name="';
        $value = $this->resolveValue($context->find('plugin_name'), $context);
        $buffer .= htmlspecialchars($value, 2, 'UTF-8');
        $buffer .= '[redis_enabled]" value="1" ';
        $value = $this->resolveValue($context->find('redis_checked'), $context);
        $buffer .= htmlspecialchars($value, 2, 'UTF-8');
        $buffer .= ' />
';
        $buffer .= $indent . '        <span>Enable Redis caching for API call results</span>
';
        $buffer .= $indent . '      </label>
';
        $buffer .= $indent . '    </fieldset> -->
';
        $buffer .= $indent . '
';
        $buffer .= $indent . '    <br />
';
        $buffer .= $indent . '
';
        $buffer .= $indent . '    <!-- mustache conditional? -->
';
        // 'authorisable' section
        $value = $context->find('authorisable');
        $buffer .= $this->section2174544e639794b641341d846dfe059a($context, $indent, $value);
        $buffer .= $indent . '
';
        $buffer .= $indent . '    <!-- if ptag test successful -->
';
        // 'importable' section
        $value = $context->find('importable');
        $buffer .= $this->sectionD923341adebaf50ef8c099dcd4791935($context, $indent, $value);
        $buffer .= $indent . '
';
        $buffer .= $indent . '    ';
        $value = $this->resolveValue($context->find('submit_button'), $context);
        $buffer .= $value;
        $buffer .= '
';
        $buffer .= $indent . '
';
        $buffer .= $indent . '    <br /><br />
';
        $buffer .= $indent . '
';
        $buffer .= $indent . '    <p>
';
        $buffer .= $indent . '      Additional documentation can be found <a target="_blank" href="https://github.com/hail/hail-wordpress">here</a>
';
        $buffer .= $indent . '    </p>
';
        $buffer .= $indent . '
';
        $buffer .= $indent . '    <br /><br />
';
        $buffer .= $indent . '
';
        $buffer .= $indent . '    <a href="#" id="hail-show-dangerous-settings" style="color: red">o</a>
';
        $buffer .= $indent . '    <div id="hail-hidden-dangerous-settings" style="display: none">
';
        $buffer .= $indent . '      <h2>Here be dragons</h2>
';
        $buffer .= $indent . '      <!-- not at all dangerous delete all button -->
';
        $buffer .= $indent . '      <a class="button button-red" href="';
        $value = $this->resolveValue($context->find('hail_delete_content_url'), $context);
        $buffer .= htmlspecialchars($value, 2, 'UTF-8');
        $buffer .= '">Clear existing imported content</a>
';
        $buffer .= $indent . '      <a class="button button-red" href="';
        $value = $this->resolveValue($context->find('hail_delete_settings_url'), $context);
        $buffer .= htmlspecialchars($value, 2, 'UTF-8');
        $buffer .= '">Reset settings (be careful)</a>
';
        $buffer .= $indent . '    </div>
';
        $buffer .= $indent . '
';
        $buffer .= $indent . '  </form>
';
        $buffer .= $indent . '
';
        $buffer .= $indent . '</div>
';
        $buffer .= $indent . '
';
        $buffer .= $indent . '<script type="text/javascript">
';
        $buffer .= $indent . '  (function() {
';
        $buffer .= $indent . '    var link = document.getElementById(\'hail-show-dangerous-settings\');
';
        $buffer .= $indent . '    var container = document.getElementById(\'hail-hidden-dangerous-settings\');
';
        $buffer .= $indent . '
';
        $buffer .= $indent . '    link.onclick = function(e) {
';
        $buffer .= $indent . '      if (e) e.preventDefault();
';
        $buffer .= $indent . '      link.style.display = \'none\';
';
        $buffer .= $indent . '      container.style.display = \'block\';
';
        $buffer .= $indent . '    };
';
        $buffer .= $indent . '  })();
';
        $buffer .= $indent . '</script>
';

        return $buffer;
    }

    private function section5c17e4078d655e9add08f81421dfe131(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        $blocksContext = array();
    
        if (!is_string($value) && is_callable($value)) {
            $source = '
  <div class="updated"><p>Import successful. {{import_results}}</p></div>
  ';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= $indent . '  <div class="updated"><p>Import successful. ';
                $value = $this->resolveValue($context->find('import_results'), $context);
                $buffer .= htmlspecialchars($value, 2, 'UTF-8');
                $buffer .= '</p></div>
';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section56c87778ddf2a0be6719f120ccbfe059(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        $blocksContext = array();
    
        if (!is_string($value) && is_callable($value)) {
            $source = '
  <div class="updated"><p>Deletion successful. {{deletion_results}}</p></div>
  ';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= $indent . '  <div class="updated"><p>Deletion successful. ';
                $value = $this->resolveValue($context->find('deletion_results'), $context);
                $buffer .= htmlspecialchars($value, 2, 'UTF-8');
                $buffer .= '</p></div>
';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section0e62cf974a12df58abcba8baca48fe34(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        $blocksContext = array();
    
        if (!is_string($value) && is_callable($value)) {
            $source = '
  <div class="updated"><p>Settings have been reset.</p></div>
  ';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= $indent . '  <div class="updated"><p>Settings have been reset.</p></div>
';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section2174544e639794b641341d846dfe059a(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        $blocksContext = array();
    
        if (!is_string($value) && is_callable($value)) {
            $source = '
    <a class="button-primary" href="{{authorization_url}}">Authorise</a>
    ';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= $indent . '    <a class="button-primary" href="';
                $value = $this->resolveValue($context->find('authorization_url'), $context);
                $buffer .= htmlspecialchars($value, 2, 'UTF-8');
                $buffer .= '">Authorise</a>
';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionD923341adebaf50ef8c099dcd4791935(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        $blocksContext = array();
    
        if (!is_string($value) && is_callable($value)) {
            $source = '
    <a class="button-primary" href="{{hail_import_url}}">Import</a>
    ';
            $result = call_user_func($value, $source, $this->lambdaHelper);
            if (strpos($result, '{{') === false) {
                $buffer .= $result;
            } else {
                $buffer .= $this->mustache
                    ->loadLambda((string) $result)
                    ->renderInternal($context);
            }
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= $indent . '    <a class="button-primary" href="';
                $value = $this->resolveValue($context->find('hail_import_url'), $context);
                $buffer .= htmlspecialchars($value, 2, 'UTF-8');
                $buffer .= '">Import</a>
';
                $context->pop();
            }
        }
    
        return $buffer;
    }

}
